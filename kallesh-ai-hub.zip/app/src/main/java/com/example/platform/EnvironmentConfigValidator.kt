package com.example.platform

import com.example.BuildConfig
import com.example.data.remote.SupabaseClient
import com.example.payment.RazorpaySdkGatewayManager

data class ConfigItemStatus(
    val keyName: String,
    val isConfigured: Boolean,
    val maskedValueOrLabel: String,
    val category: String,
    val isSecret: Boolean = true,
    val isRequired: Boolean = true
)

object EnvironmentConfigValidator {

    private fun isReal(candidate: String?): Boolean {
        if (candidate.isNullOrBlank()) return false
        val trimmed = candidate.trim()
        val upper = trimmed.uppercase()
        return !upper.startsWith("MY_") &&
            !upper.startsWith("YOUR_") &&
            !upper.contains("YOUR_") &&
            upper != "NULL" &&
            upper != "NONE"
    }

    val supabaseUrlConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.SUPABASE_URL }.getOrNull()) || isReal(SupabaseClient.supabaseUrl)

    val supabaseAnonKeyConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.SUPABASE_ANON_KEY }.getOrNull()) || isReal(SupabaseClient.apiKey)

    val supabaseProjectIdConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.SUPABASE_PROJECT_ID }.getOrNull()) || isReal(SupabaseClient.projectId)

    val geminiApiKeyConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.GEMINI_API_KEY }.getOrNull()) ||
            isReal(runCatching { BuildConfig.GOOGLE_AI_API_KEY }.getOrNull()) ||
            isReal(runCatching { BuildConfig.AI_API_KEY }.getOrNull())

    val openAiApiKeyConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.OPENAI_API_KEY }.getOrNull())

    val imageApiKeyConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.IMAGE_GENERATION_API_KEY }.getOrNull()) || geminiApiKeyConfigured

    val videoApiKeyConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.VIDEO_GENERATION_API_KEY }.getOrNull()) || geminiApiKeyConfigured

    val databaseUrlConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.DATABASE_URL }.getOrNull())

    val authSecretConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.AUTH_SECRET }.getOrNull())

    val googleClientIdConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.GOOGLE_CLIENT_ID }.getOrNull())

    val googleClientSecretConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.GOOGLE_CLIENT_SECRET }.getOrNull())

    val razorpayKeyIdConfigured: Boolean
        get() = RazorpaySdkGatewayManager.isMerchantKeyConfigured()

    val razorpaySecretConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.RAZORPAY_KEY_SECRET }.getOrNull())

    val razorpayWebhookSecretConfigured: Boolean
        get() = isReal(runCatching { BuildConfig.RAZORPAY_WEBHOOK_SECRET }.getOrNull())

    fun getAllConfigItems(): List<ConfigItemStatus> {
        val sbUrl = runCatching { BuildConfig.SUPABASE_URL }.getOrNull()?.takeIf { isReal(it) } ?: SupabaseClient.supabaseUrl
        val sbKey = runCatching { BuildConfig.SUPABASE_ANON_KEY }.getOrNull()?.takeIf { isReal(it) } ?: SupabaseClient.apiKey
        val sbProj = runCatching { BuildConfig.SUPABASE_PROJECT_ID }.getOrNull()?.takeIf { isReal(it) } ?: SupabaseClient.projectId

        val geminiKey = runCatching { BuildConfig.GEMINI_API_KEY }.getOrNull()?.takeIf { isReal(it) }
            ?: runCatching { BuildConfig.GOOGLE_AI_API_KEY }.getOrNull()?.takeIf { isReal(it) }
            ?: runCatching { BuildConfig.AI_API_KEY }.getOrNull()?.takeIf { isReal(it) }

        val openAiKey = runCatching { BuildConfig.OPENAI_API_KEY }.getOrNull()?.takeIf { isReal(it) }
        val imageKey = runCatching { BuildConfig.IMAGE_GENERATION_API_KEY }.getOrNull()?.takeIf { isReal(it) } ?: geminiKey
        val imgModel = runCatching { BuildConfig.IMAGE_GENERATION_MODEL }.getOrNull()?.takeIf { it.isNotBlank() } ?: "gemini-2.5-flash-image"
        val videoKey = runCatching { BuildConfig.VIDEO_GENERATION_API_KEY }.getOrNull()?.takeIf { isReal(it) } ?: geminiKey
        val vidModel = runCatching { BuildConfig.VIDEO_GENERATION_MODEL }.getOrNull()?.takeIf { it.isNotBlank() } ?: "veo-3.1-fast-generate-preview"
        val dbUrl = runCatching { BuildConfig.DATABASE_URL }.getOrNull()?.takeIf { isReal(it) }
        val authSecret = runCatching { BuildConfig.AUTH_SECRET }.getOrNull()?.takeIf { isReal(it) }
        val gClientId = runCatching { BuildConfig.GOOGLE_CLIENT_ID }.getOrNull()?.takeIf { isReal(it) }
        val gClientSecret = runCatching { BuildConfig.GOOGLE_CLIENT_SECRET }.getOrNull()?.takeIf { isReal(it) }
        val rzpKeyId = runCatching { BuildConfig.RAZORPAY_KEY_ID }.getOrNull()?.takeIf { isReal(it) }
        val rzpKeySecret = runCatching { BuildConfig.RAZORPAY_KEY_SECRET }.getOrNull()?.takeIf { isReal(it) }
        val rzpWebhook = runCatching { BuildConfig.RAZORPAY_WEBHOOK_SECRET }.getOrNull()?.takeIf { isReal(it) }
        val prodUrl = runCatching { BuildConfig.PRODUCTION_URL }.getOrNull()?.takeIf { it.isNotBlank() } ?: "https://kalleshaihub.com"
        val backendApiUrl = runCatching { BuildConfig.BACKEND_API_URL }.getOrNull()?.takeIf { it.isNotBlank() } ?: "https://kalleshaihub.com/api"
        val authProvider = runCatching { BuildConfig.AUTH_PROVIDER }.getOrNull()?.takeIf { it.isNotBlank() } ?: "supabase_auth_and_session"
        val dbProvider = runCatching { BuildConfig.DATABASE_PROVIDER }.getOrNull()?.takeIf { it.isNotBlank() } ?: "supabase_postgresql"
        val aiDefaultModel = runCatching { BuildConfig.AI_DEFAULT_MODEL }.getOrNull()?.takeIf { it.isNotBlank() } ?: "gemini-3-flash-preview"
        val ttsVoice = runCatching { BuildConfig.TTS_VOICE_ID }.getOrNull()?.takeIf { it.isNotBlank() } ?: "Puck"

        return listOf(
            ConfigItemStatus("SUPABASE_URL", isReal(sbUrl), if (isReal(sbUrl)) sbUrl else "Missing (Required for Supabase)", "Supabase", isSecret = false),
            ConfigItemStatus("SUPABASE_ANON_KEY", isReal(sbKey), if (isReal(sbKey)) "Configured (${sbKey.take(12)}...)" else "Missing (Required)", "Supabase", isSecret = true),
            ConfigItemStatus("SUPABASE_PROJECT_ID", isReal(sbProj), if (isReal(sbProj)) sbProj else "Missing", "Supabase", isSecret = false),
            ConfigItemStatus("OPENAI_API_KEY", openAiKey != null, if (openAiKey != null) "Configured (sk-...)" else "Not Configured (Optional)", "AI Providers", isSecret = true, isRequired = false),
            ConfigItemStatus("AI_API_KEY", geminiKey != null, if (geminiKey != null) "Active & Ready (${geminiKey.take(8)}...)" else "Not Configured (Set in Secrets)", "AI Providers", isSecret = true),
            ConfigItemStatus("IMAGE_GENERATION_API_KEY", imageKey != null, if (imageKey != null) "Active" else "Using AI_API_KEY", "Creative Studios", isSecret = true, isRequired = false),
            ConfigItemStatus("IMAGE_GENERATION_MODEL", true, imgModel, "Creative Studios", isSecret = false, isRequired = false),
            ConfigItemStatus("VIDEO_GENERATION_API_KEY", videoKey != null, if (videoKey != null) "Active" else "Using AI_API_KEY", "Creative Studios", isSecret = true, isRequired = false),
            ConfigItemStatus("VIDEO_GENERATION_MODEL", true, vidModel, "Creative Studios", isSecret = false, isRequired = false),
            ConfigItemStatus("DATABASE_URL", dbUrl != null, if (dbUrl != null) "PostgreSQL Connected" else "Not Configured (Using Supabase & Room)", "Database", isSecret = true, isRequired = false),
            ConfigItemStatus("AUTH_SECRET", authSecret != null, if (authSecret != null) "Configured (Secure Server Secret)" else "Not Configured", "Auth", isSecret = true, isRequired = false),
            ConfigItemStatus("GOOGLE_CLIENT_ID", gClientId != null, if (gClientId != null) gClientId else "Not Configured", "OAuth", isSecret = false, isRequired = false),
            ConfigItemStatus("GOOGLE_CLIENT_SECRET", gClientSecret != null, if (gClientSecret != null) "Configured (Hidden)" else "Not Configured", "OAuth", isSecret = true, isRequired = false),
            ConfigItemStatus("GOOGLE_REDIRECT_URI", true, "https://kalleshaihub.com/auth/callback", "OAuth", isSecret = false, isRequired = false),
            ConfigItemStatus("RAZORPAY_KEY_ID", rzpKeyId != null, if (rzpKeyId != null) "${rzpKeyId.take(12)}..." else "Sandbox Mode (Add in Secrets for Live)", "Payments", isSecret = false, isRequired = false),
            ConfigItemStatus("RAZORPAY_KEY_SECRET", rzpKeySecret != null, if (rzpKeySecret != null) "Configured (Hidden)" else "Sandbox Verified", "Payments", isSecret = true, isRequired = false),
            ConfigItemStatus("RAZORPAY_WEBHOOK_SECRET", rzpWebhook != null, if (rzpWebhook != null) "Configured (Hidden)" else "Not Configured", "Payments", isSecret = true, isRequired = false),
            ConfigItemStatus("PRODUCTION_URL", true, prodUrl, "Platform", isSecret = false, isRequired = false),
            ConfigItemStatus("BACKEND_API_URL", true, backendApiUrl, "Platform", isSecret = false, isRequired = false),
            ConfigItemStatus("AUTH_PROVIDER", true, authProvider, "Auth", isSecret = false, isRequired = false),
            ConfigItemStatus("DATABASE_PROVIDER", true, dbProvider, "Database", isSecret = false, isRequired = false),
            ConfigItemStatus("AI_DEFAULT_MODEL", true, aiDefaultModel, "AI Providers", isSecret = false, isRequired = false),
            ConfigItemStatus("TTS_VOICE_ID", true, ttsVoice, "Audio", isSecret = false, isRequired = false)
        )
    }
}
