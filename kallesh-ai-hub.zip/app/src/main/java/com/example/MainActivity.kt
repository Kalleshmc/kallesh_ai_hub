package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UiState
import com.example.payment.RazorpayPaymentData
import com.example.payment.RazorpayPaymentResultWithDataListener
import com.example.payment.RazorpaySdkCallbackEvent
import com.example.payment.RazorpaySdkGatewayManager
import com.example.ui.KalleshMainShell
import com.example.ui.auth.AuthLandingScreen
import com.example.ui.auth.AuthenticatedSessionUser
import com.example.ui.auth.SecureAuthManager
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.auth.AppAuthState
import com.example.ui.viewmodel.KalleshHubViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity(), RazorpayPaymentResultWithDataListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        RazorpaySdkGatewayManager.preload(applicationContext)
        val initialDeepLinkPath = intent?.data?.path ?: intent?.data?.toString()
        SecureAuthManager.initialize(applicationContext, initialDeepLinkPath)
        handleIncomingOAuthCallback(intent)
        setContent {
            KalleshAiHubRoot(
                application = application,
                initialDeepLinkPath = initialDeepLinkPath
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingOAuthCallback(intent)
    }

    private fun handleIncomingOAuthCallback(incomingIntent: Intent?) {
        val data = incomingIntent?.data ?: return
        val path = data.path.orEmpty()
        val fragment = data.fragment.orEmpty()
        val fullUri = incomingIntent.dataString.orEmpty()
        if (path.contains("callback") || fragment.contains("id_token") || fragment.contains("access_token") || data.getQueryParameter("code") != null || fullUri.contains("auth/callback")) {
            val idToken = data.getQueryParameter("id_token")
                ?: fragment.split("&").firstOrNull { it.startsWith("id_token=") }?.removePrefix("id_token=")
                ?: data.getQueryParameter("code")
            val email = data.getQueryParameter("email").orEmpty()
            val displayName = data.getQueryParameter("name").orEmpty()
            if (!idToken.isNullOrBlank()) {
                lifecycleScope.launch {
                    SecureAuthManager.handleGoogleSignInResult(
                        context = applicationContext,
                        idToken = idToken,
                        rawEmail = email,
                        rawDisplayName = displayName,
                        targetRoute = "/dashboard"
                    )
                }
            }
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String?, paymentData: RazorpayPaymentData?) {
        RazorpaySdkGatewayManager.onSdkPaymentSuccess(razorpayPaymentId, paymentData)
    }

    override fun onPaymentError(code: Int, response: String?, paymentData: RazorpayPaymentData?) {
        RazorpaySdkGatewayManager.onSdkPaymentError(code, response, paymentData)
    }
}

@Composable
fun AuthLoadingSplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF070A12),
                        Color(0xFF0D1528),
                        Color(0xFF070A12)
                    )
                )
            )
            .testTag("auth_loading_splash"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(
                        width = 2.dp,
                        brush = Brush.linearGradient(
                            listOf(Color(0xFF00E5FF), Color(0xFF6366F1), Color(0xFFA855F7))
                        ),
                        shape = RoundedCornerShape(26.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kallesh_ref_logo),
                    contentDescription = "Kallesh AI Hub",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Text(
                text = "Kallesh AI Hub",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            CircularProgressIndicator(
                color = Color(0xFF00E5FF),
                strokeWidth = 3.dp,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("auth_loading_spinner")
            )
            Text(
                text = "Verifying authenticated session...",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8)
            )
        }
    }
}

@Composable
fun KalleshAiHubRoot(
    application: android.app.Application,
    initialDeepLinkPath: String? = null
) {
    val authState by SecureAuthManager.authState.collectAsStateWithLifecycle()
    var pendingRoutePath by remember { mutableStateOf(initialDeepLinkPath) }

    when (val state = authState) {
        is AppAuthState.Loading -> {
            MyApplicationTheme(darkTheme = true) {
                AuthLoadingSplashScreen()
            }
        }

        is AppAuthState.Unauthenticated -> {
            MyApplicationTheme(darkTheme = true) {
                AuthLandingScreen(
                    onAuthSuccess = {
                        val session = SecureAuthManager.getSavedSession(application)
                        if (session != null) {
                            SecureAuthManager.setAuthenticated(
                                context = application,
                                session = session,
                                targetRoute = pendingRoutePath ?: "/dashboard"
                            )
                        }
                    },
                    onOpenPublicRoute = { routePath ->
                        pendingRoutePath = routePath
                    }
                )
            }
        }

        is AppAuthState.Authenticated -> {
            val activeUid = state.sessionUser.uid
            val hubViewModel: KalleshHubViewModel = viewModel(
                key = "kallesh_hub_$activeUid",
                factory = KalleshHubViewModel.Factory(application, activeUid)
            )

            LaunchedEffect(state.targetRoute, pendingRoutePath) {
                val route = pendingRoutePath ?: state.targetRoute
                if (!route.isNullOrBlank()) {
                    hubViewModel.handleDeepLinkPath(route)
                    pendingRoutePath = null
                }
            }

            val sdkPaymentEvent by RazorpaySdkGatewayManager.latestSdkEvent.collectAsStateWithLifecycle()
            LaunchedEffect(sdkPaymentEvent) {
                when (val ev = sdkPaymentEvent) {
                    is RazorpaySdkCallbackEvent.Success -> {
                        hubViewModel.verifyAndCompletePlanPayment(
                            orderId = ev.orderId,
                            paymentId = ev.paymentId,
                            signature = ev.signature,
                            paymentMethod = ev.paymentMethod
                        )
                        RazorpaySdkGatewayManager.consumeSdkEvent()
                    }
                    is RazorpaySdkCallbackEvent.Failure -> {
                        hubViewModel.cancelOrFailPlanPayment(ev.errorDescription)
                        RazorpaySdkGatewayManager.consumeSdkEvent()
                    }
                    null -> Unit
                }
            }

            val profileState by hubViewModel.userProfileState.collectAsStateWithLifecycle()
            val themePref = (profileState as? UiState.Success)?.data?.themeMode ?: "DARK"
            val useDark = when (themePref.uppercase()) {
                "LIGHT" -> false
                "SYSTEM" -> isSystemInDarkTheme()
                else -> true
            }

            MyApplicationTheme(darkTheme = useDark) {
                KalleshMainShell(
                    viewModel = hubViewModel,
                    onSignedOut = {
                        SecureAuthManager.clearSession(application)
                        runCatching { Firebase.auth.signOut() }
                        pendingRoutePath = null
                    }
                )
            }
        }
    }
}
