package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.example.data.model.AppointmentBooking
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

data class SupabaseUser(
    val id: String,
    val email: String,
    val displayName: String = "",
    val avatarUrl: String? = null,
    val createdAt: String = ""
)

data class SupabaseAuthSession(
    val user: SupabaseUser,
    val accessToken: String,
    val refreshToken: String,
    val expiresIn: Long = 3600L,
    val expiresAtMs: Long = System.currentTimeMillis() + (3600L * 1000L)
)

data class SupabaseProfile(
    val id: String,
    val displayName: String,
    val email: String,
    val avatarUrl: String? = null,
    val plan: String = "FREE",
    val role: String = "USER",
    val hasSeenFounderIntro: Boolean = false,
    val themeMode: String = "DARK",
    val preferredLanguage: String = "English",
    val createdAt: String = "",
    val updatedAt: String = ""
)

data class SupabaseConversation(
    val id: String,
    val userId: String,
    val title: String,
    val model: String = "gemini-3.5-flash",
    val systemPrompt: String? = null,
    val isPinned: Boolean = false,
    val isShared: Boolean = false,
    val messageCount: Int = 0,
    val createdAt: String = "",
    val updatedAt: String = ""
)

data class SupabaseMessage(
    val id: String,
    val conversationId: String,
    val userId: String,
    val sender: String,
    val content: String,
    val model: String = "gemini-3.5-flash",
    val citations: List<String> = emptyList(),
    val feedback: String = "NONE",
    val createdAt: String = ""
)

data class SupabaseToolUsage(
    val id: String,
    val userId: String,
    val toolType: String,
    val prompt: String,
    val output: String? = null,
    val tokensUsed: Int = 0,
    val status: String = "COMPLETED",
    val createdAt: String = ""
)

object SupabaseClient {
    private const val TAG = "SupabaseClient"

    const val DEFAULT_PROJECT_ID = "rcydbnmzgywuybfkklbq"
    const val DEFAULT_URL = "https://rcydbnmzgywuybfkklbq.supabase.co"
    const val DEFAULT_API_KEY = "sb_secret_Mneu0aLeJprNbIWMlFZR_g_jh3pZyEY"

    val projectId: String
        get() = runCatching { BuildConfig.SUPABASE_PROJECT_ID }.getOrNull()?.takeIf { it.isNotBlank() && !it.startsWith("MY_") } ?: DEFAULT_PROJECT_ID

    val supabaseUrl: String
        get() = runCatching { BuildConfig.SUPABASE_URL }.getOrNull()?.takeIf { it.isNotBlank() && !it.startsWith("MY_") } ?: DEFAULT_URL

    val apiKey: String
        get() = runCatching { BuildConfig.SUPABASE_ANON_KEY }.getOrNull()?.takeIf { it.isNotBlank() && !it.startsWith("MY_") } ?: DEFAULT_API_KEY

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    const val SUPABASE_SETUP_SQL_QUERY = """-- =========================================================================
-- KALLESH AI HUB: Complete Supabase PostgreSQL Schema & Security Migration
-- Project ID: rcydbnmzgywuybfkklbq
-- Run this in your Supabase Dashboard > SQL Editor > "New Query"
-- =========================================================================

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    display_name TEXT,
    email TEXT,
    avatar_url TEXT,
    plan TEXT NOT NULL DEFAULT 'FREE',
    role TEXT NOT NULL DEFAULT 'USER',
    has_seen_founder_intro BOOLEAN NOT NULL DEFAULT false,
    theme_mode TEXT NOT NULL DEFAULT 'DARK',
    preferred_language TEXT NOT NULL DEFAULT 'English',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_plan ON public.profiles(plan);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public and authenticated users can view profiles" ON public.profiles;
CREATE POLICY "Public and authenticated users can view profiles"
    ON public.profiles FOR SELECT
    TO anon, authenticated
    USING (true);

DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
CREATE POLICY "Users can insert their own profile"
    ON public.profiles FOR INSERT
    TO anon, authenticated
    WITH CHECK (auth.uid() = id OR auth.uid() IS NULL);

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
    ON public.profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- 2. AI CONVERSATIONS TABLE
CREATE TABLE IF NOT EXISTS public.ai_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT 'New Conversation',
    model TEXT NOT NULL DEFAULT 'gemini-3.5-flash',
    system_prompt TEXT,
    is_pinned BOOLEAN NOT NULL DEFAULT false,
    is_shared BOOLEAN NOT NULL DEFAULT false,
    message_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_ai_conversations_user_id ON public.ai_conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_conversations_updated ON public.ai_conversations(updated_at DESC);

ALTER TABLE public.ai_conversations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own conversations" ON public.ai_conversations;
CREATE POLICY "Users can view their own conversations"
    ON public.ai_conversations FOR SELECT
    TO anon, authenticated
    USING (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

DROP POLICY IF EXISTS "Users can insert their own conversations" ON public.ai_conversations;
CREATE POLICY "Users can insert their own conversations"
    ON public.ai_conversations FOR INSERT
    TO anon, authenticated
    WITH CHECK (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

DROP POLICY IF EXISTS "Users can update their own conversations" ON public.ai_conversations;
CREATE POLICY "Users can update their own conversations"
    ON public.ai_conversations FOR UPDATE
    TO anon, authenticated
    USING (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL)
    WITH CHECK (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

DROP POLICY IF EXISTS "Users can delete their own conversations" ON public.ai_conversations;
CREATE POLICY "Users can delete their own conversations"
    ON public.ai_conversations FOR DELETE
    TO anon, authenticated
    USING (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

-- 3. AI MESSAGES TABLE
CREATE TABLE IF NOT EXISTS public.ai_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES public.ai_conversations(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    sender TEXT NOT NULL DEFAULT 'user',
    content TEXT NOT NULL,
    model TEXT NOT NULL DEFAULT 'gemini-3.5-flash',
    citations JSONB DEFAULT '[]'::jsonb,
    feedback TEXT NOT NULL DEFAULT 'NONE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_ai_messages_conv ON public.ai_messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_ai_messages_user ON public.ai_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_messages_created ON public.ai_messages(created_at ASC);

ALTER TABLE public.ai_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own messages" ON public.ai_messages;
CREATE POLICY "Users can view their own messages"
    ON public.ai_messages FOR SELECT
    TO anon, authenticated
    USING (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

DROP POLICY IF EXISTS "Users can insert their own messages" ON public.ai_messages;
CREATE POLICY "Users can insert their own messages"
    ON public.ai_messages FOR INSERT
    TO anon, authenticated
    WITH CHECK (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

-- 4. AI TOOL USAGE TABLE
CREATE TABLE IF NOT EXISTS public.ai_tool_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    tool_type TEXT NOT NULL,
    prompt TEXT NOT NULL,
    output TEXT,
    tokens_used INT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'COMPLETED',
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_tool_usage_user ON public.ai_tool_usage(user_id);
CREATE INDEX IF NOT EXISTS idx_tool_usage_type ON public.ai_tool_usage(tool_type);
CREATE INDEX IF NOT EXISTS idx_tool_usage_created ON public.ai_tool_usage(created_at DESC);

ALTER TABLE public.ai_tool_usage ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own tool usage" ON public.ai_tool_usage;
CREATE POLICY "Users can view their own tool usage"
    ON public.ai_tool_usage FOR SELECT
    TO anon, authenticated
    USING (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

DROP POLICY IF EXISTS "Users can insert their own tool usage" ON public.ai_tool_usage;
CREATE POLICY "Users can insert their own tool usage"
    ON public.ai_tool_usage FOR INSERT
    TO anon, authenticated
    WITH CHECK (auth.uid()::text = user_id OR user_id = current_setting('request.jwt.claim.sub', true) OR auth.uid() IS NULL);

-- 5. APPOINTMENTS TABLE
CREATE TABLE IF NOT EXISTS public.appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    service TEXT NOT NULL DEFAULT 'AI Strategy & Consultation',
    appointment_date DATE NOT NULL,
    appointment_time TEXT NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    user_id TEXT,
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_appointments_created_at ON public.appointments (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON public.appointments (appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_email ON public.appointments (email);

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow anonymous and authenticated form submissions" ON public.appointments;
CREATE POLICY "Allow anonymous and authenticated form submissions"
    ON public.appointments FOR INSERT
    TO anon, authenticated
    WITH CHECK (true);

DROP POLICY IF EXISTS "Allow reading appointments" ON public.appointments;
CREATE POLICY "Allow reading appointments"
    ON public.appointments FOR SELECT
    TO anon, authenticated
    USING (true);

-- 6. AUTOMATIC USER PROFILE TRIGGER
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS ${'$'}${'$'}
BEGIN
    INSERT INTO public.profiles (id, display_name, email, avatar_url, plan, role, has_seen_founder_intro)
    VALUES (
        new.id,
        COALESCE(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)),
        new.email,
        new.raw_user_meta_data->>'avatar_url',
        'FREE',
        'USER',
        false
    )
    ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        display_name = COALESCE(EXCLUDED.display_name, public.profiles.display_name),
        updated_at = timezone('utc'::text, now());
    RETURN new;
END;
${'$'}${'$'} LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Grant permissions to Supabase roles
GRANT ALL ON TABLE public.profiles TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.ai_conversations TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.ai_messages TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.ai_tool_usage TO anon, authenticated, service_role;
GRANT ALL ON TABLE public.appointments TO anon, authenticated, service_role;
"""

    // =========================================================================
    // AUTHENTICATION METHODS
    // =========================================================================

    suspend fun signUp(
        email: String,
        password: String,
        displayName: String = ""
    ): Result<SupabaseAuthSession> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/auth/v1/signup"
            val payload = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("password", password)
                if (displayName.isNotBlank()) {
                    put("data", JSONObject().apply {
                        put("display_name", displayName.trim())
                    })
                }
            }

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                val errJson = runCatching { JSONObject(responseBody) }.getOrNull()
                val msg = errJson?.optString("msg")
                    ?: errJson?.optString("error_description")
                    ?: errJson?.optString("message")
                    ?: "Supabase signup failed (HTTP ${response.code})."
                if (msg.contains("already registered", ignoreCase = true) || msg.contains("User already exists", ignoreCase = true)) {
                    throw IllegalStateException("An account with this email is already registered in Supabase. Please use Log In instead.")
                }
                throw IllegalStateException(msg)
            }

            val json = JSONObject(responseBody)
            val accessToken = json.optString("access_token", "")
            val refreshToken = json.optString("refresh_token", "")
            val expiresIn = json.optLong("expires_in", 3600L)

            val userObj = json.optJSONObject("user") ?: json
            val uid = userObj.optString("id", UUID.randomUUID().toString())
            val userEmail = userObj.optString("email", email.trim().lowercase())
            val metadata = userObj.optJSONObject("user_metadata")
            val resolvedName = metadata?.optString("display_name")?.ifBlank { displayName } ?: displayName
            val avatarUrl = if (metadata != null && !metadata.isNull("avatar_url")) metadata.optString("avatar_url") else null

            val session = SupabaseAuthSession(
                user = SupabaseUser(
                    id = uid,
                    email = userEmail,
                    displayName = resolvedName.ifBlank { userEmail.substringBefore("@") },
                    avatarUrl = avatarUrl,
                    createdAt = userObj.optString("created_at", "")
                ),
                accessToken = accessToken.ifBlank { "tok_sb_$uid" },
                refreshToken = refreshToken,
                expiresIn = expiresIn,
                expiresAtMs = System.currentTimeMillis() + (expiresIn * 1000L)
            )

            // Ensure profile exists in profiles table
            runCatching {
                upsertProfile(
                    userId = uid,
                    email = userEmail,
                    displayName = session.user.displayName,
                    avatarUrl = avatarUrl,
                    plan = "FREE",
                    hasSeenFounderIntro = false,
                    token = session.accessToken
                )
            }

            session
        }
    }

    suspend fun signIn(
        email: String,
        password: String
    ): Result<SupabaseAuthSession> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/auth/v1/token?grant_type=password"
            val payload = JSONObject().apply {
                put("email", email.trim().lowercase())
                put("password", password)
            }

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                val errJson = runCatching { JSONObject(responseBody) }.getOrNull()
                val msg = errJson?.optString("error_description")
                    ?: errJson?.optString("msg")
                    ?: errJson?.optString("message")
                    ?: "Invalid email or password."
                if (msg.contains("Invalid login credentials", ignoreCase = true)) {
                    throw IllegalStateException("Invalid email or password. Please verify your Supabase credentials.")
                }
                throw IllegalStateException(msg)
            }

            val json = JSONObject(responseBody)
            val accessToken = json.getString("access_token")
            val refreshToken = json.optString("refresh_token", "")
            val expiresIn = json.optLong("expires_in", 3600L)

            val userObj = json.getJSONObject("user")
            val uid = userObj.getString("id")
            val userEmail = userObj.optString("email", email.trim().lowercase())
            val metadata = userObj.optJSONObject("user_metadata")
            val displayName = metadata?.optString("display_name", "").orEmpty()
            val avatarUrl = if (metadata != null && !metadata.isNull("avatar_url")) metadata.optString("avatar_url") else null

            SupabaseAuthSession(
                user = SupabaseUser(
                    id = uid,
                    email = userEmail,
                    displayName = displayName.ifBlank { userEmail.substringBefore("@") },
                    avatarUrl = avatarUrl,
                    createdAt = userObj.optString("created_at", "")
                ),
                accessToken = accessToken,
                refreshToken = refreshToken,
                expiresIn = expiresIn,
                expiresAtMs = System.currentTimeMillis() + (expiresIn * 1000L)
            )
        }
    }

    suspend fun signOut(accessToken: String? = null): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/auth/v1/logout"
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .post("{}".toRequestBody(jsonMediaType))

            if (!accessToken.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $accessToken")
            }

            httpClient.newCall(requestBuilder.build()).execute()
            Unit
        }
    }

    suspend fun resetPassword(email: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/auth/v1/recover"
            val payload = JSONObject().apply {
                put("email", email.trim().lowercase())
            }

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                val errJson = runCatching { JSONObject(responseBody) }.getOrNull()
                val msg = errJson?.optString("msg") ?: errJson?.optString("message") ?: "Password reset failed."
                throw IllegalStateException(msg)
            }

            "Password recovery instructions sent to ${email.trim()}. Please check your email to reset your password."
        }
    }

    // =========================================================================
    // PROFILES METHODS
    // =========================================================================

    suspend fun fetchProfile(userId: String, token: String? = null): Result<SupabaseProfile?> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/profiles?id=eq.$userId&select=*"
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Accept", "application/json")
                .get()

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                return@runCatching null
            }

            val jsonArray = JSONArray(responseBody)
            if (jsonArray.length() == 0) return@runCatching null

            val item = jsonArray.getJSONObject(0)
            SupabaseProfile(
                id = item.optString("id", userId),
                displayName = item.optString("display_name", "Explorer"),
                email = item.optString("email", ""),
                avatarUrl = if (!item.isNull("avatar_url")) item.optString("avatar_url") else null,
                plan = item.optString("plan", "FREE"),
                role = item.optString("role", "USER"),
                hasSeenFounderIntro = item.optBoolean("has_seen_founder_intro", false),
                themeMode = item.optString("theme_mode", "DARK"),
                preferredLanguage = item.optString("preferred_language", "English"),
                createdAt = item.optString("created_at", ""),
                updatedAt = item.optString("updated_at", "")
            )
        }
    }

    suspend fun upsertProfile(
        userId: String,
        email: String,
        displayName: String,
        avatarUrl: String? = null,
        plan: String = "FREE",
        hasSeenFounderIntro: Boolean = false,
        token: String? = null
    ): Result<SupabaseProfile> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/profiles"
            val payload = JSONObject().apply {
                put("id", userId)
                put("email", email.trim().lowercase())
                put("display_name", displayName.trim())
                if (avatarUrl != null) put("avatar_url", avatarUrl)
                put("plan", plan)
                put("has_seen_founder_intro", hasSeenFounderIntro)
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "resolution=merge-duplicates,return=representation")
                .post(payload.toString().toRequestBody(jsonMediaType))

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.w(TAG, "Profile upsert notice: ${response.code} $responseBody")
            }

            SupabaseProfile(
                id = userId,
                displayName = displayName,
                email = email,
                avatarUrl = avatarUrl,
                plan = plan,
                hasSeenFounderIntro = hasSeenFounderIntro
            )
        }
    }

    // =========================================================================
    // AI CONVERSATIONS & CHAT MESSAGES
    // =========================================================================

    suspend fun fetchConversations(userId: String, token: String? = null): Result<List<SupabaseConversation>> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_conversations?user_id=eq.$userId&order=updated_at.desc&select=*"
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Accept", "application/json")
                .get()

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                return@runCatching emptyList()
            }

            val jsonArray = JSONArray(responseBody)
            val list = mutableListOf<SupabaseConversation>()
            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.optJSONObject(i) ?: continue
                list.add(
                    SupabaseConversation(
                        id = item.optString("id", ""),
                        userId = item.optString("user_id", userId),
                        title = item.optString("title", "New Conversation"),
                        model = item.optString("model", "gemini-3.5-flash"),
                        systemPrompt = if (!item.isNull("system_prompt")) item.optString("system_prompt") else null,
                        isPinned = item.optBoolean("is_pinned", false),
                        isShared = item.optBoolean("is_shared", false),
                        messageCount = item.optInt("message_count", 0),
                        createdAt = item.optString("created_at", ""),
                        updatedAt = item.optString("updated_at", "")
                    )
                )
            }
            list
        }
    }

    suspend fun createConversation(
        id: String = UUID.randomUUID().toString(),
        userId: String,
        title: String,
        model: String = "gemini-3.5-flash",
        token: String? = null
    ): Result<SupabaseConversation> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_conversations"
            val payload = JSONObject().apply {
                if (id.isNotBlank() && id.contains("-")) put("id", id)
                put("user_id", userId)
                put("title", title.trim().ifBlank { "New Conversation" })
                put("model", model)
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation")
                .post(payload.toString().toRequestBody(jsonMediaType))

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            val createdId = runCatching {
                if (responseBody.trim().startsWith("[")) JSONArray(responseBody).optJSONObject(0)?.optString("id")
                else JSONObject(responseBody).optString("id")
            }.getOrNull() ?: id

            SupabaseConversation(
                id = createdId,
                userId = userId,
                title = title,
                model = model
            )
        }
    }

    suspend fun renameConversation(
        conversationId: String,
        userId: String,
        newTitle: String,
        token: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_conversations?id=eq.$conversationId&user_id=eq.$userId"
            val payload = JSONObject().apply {
                put("title", newTitle.trim())
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .patch(payload.toString().toRequestBody(jsonMediaType))

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            httpClient.newCall(requestBuilder.build()).execute()
            Unit
        }
    }

    suspend fun deleteConversation(
        conversationId: String,
        userId: String,
        token: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_conversations?id=eq.$conversationId&user_id=eq.$userId"
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .delete()

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            httpClient.newCall(requestBuilder.build()).execute()
            Unit
        }
    }

    suspend fun fetchMessages(conversationId: String, token: String? = null): Result<List<SupabaseMessage>> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_messages?conversation_id=eq.$conversationId&order=created_at.asc&select=*"
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Accept", "application/json")
                .get()

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                return@runCatching emptyList()
            }

            val jsonArray = JSONArray(responseBody)
            val list = mutableListOf<SupabaseMessage>()
            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.optJSONObject(i) ?: continue
                list.add(
                    SupabaseMessage(
                        id = item.optString("id", ""),
                        conversationId = item.optString("conversation_id", conversationId),
                        userId = item.optString("user_id", ""),
                        sender = item.optString("sender", "user"),
                        content = item.optString("content", ""),
                        model = item.optString("model", "gemini-3.5-flash"),
                        feedback = item.optString("feedback", "NONE"),
                        createdAt = item.optString("created_at", "")
                    )
                )
            }
            list
        }
    }

    suspend fun saveMessage(
        id: String = UUID.randomUUID().toString(),
        conversationId: String,
        userId: String,
        role: String,
        content: String,
        model: String = "gemini-3.5-flash",
        citations: List<String> = emptyList(),
        token: String? = null
    ): Result<SupabaseMessage> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_messages"
            val payload = JSONObject().apply {
                if (id.isNotBlank() && id.contains("-")) put("id", id)
                put("conversation_id", conversationId)
                put("user_id", userId)
                put("sender", role)
                put("content", content)
                put("model", model)
                if (citations.isNotEmpty()) {
                    put("citations", JSONArray(citations))
                }
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation")
                .post(payload.toString().toRequestBody(jsonMediaType))

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            val createdId = runCatching {
                if (responseBody.trim().startsWith("[")) JSONArray(responseBody).optJSONObject(0)?.optString("id")
                else JSONObject(responseBody).optString("id")
            }.getOrNull() ?: id

            SupabaseMessage(
                id = createdId,
                conversationId = conversationId,
                userId = userId,
                sender = role,
                content = content,
                model = model,
                citations = citations
            )
        }
    }

    // =========================================================================
    // AI TOOL USAGE TRACKING
    // =========================================================================

    suspend fun recordToolUsage(
        userId: String,
        toolType: String,
        prompt: String,
        output: String? = null,
        tokensUsed: Int = 0,
        status: String = "COMPLETED",
        token: String? = null
    ): Result<SupabaseToolUsage> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/ai_tool_usage"
            val payload = JSONObject().apply {
                put("user_id", userId)
                put("tool_type", toolType)
                put("prompt", prompt.take(2000))
                if (output != null) put("output", output.take(4000))
                put("tokens_used", tokensUsed)
                put("status", status)
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation")
                .post(payload.toString().toRequestBody(jsonMediaType))

            if (!token.isNullOrBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $token")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            val createdId = runCatching {
                if (responseBody.trim().startsWith("[")) JSONArray(responseBody).optJSONObject(0)?.optString("id")
                else JSONObject(responseBody).optString("id")
            }.getOrNull() ?: UUID.randomUUID().toString()

            SupabaseToolUsage(
                id = createdId,
                userId = userId,
                toolType = toolType,
                prompt = prompt,
                output = output,
                tokensUsed = tokensUsed,
                status = status
            )
        }
    }

    // =========================================================================
    // APPOINTMENTS
    // =========================================================================

    suspend fun bookAppointment(
        name: String,
        email: String,
        phone: String,
        service: String,
        appointmentDate: String,
        appointmentTime: String,
        notes: String,
        userId: String? = null
    ): Result<AppointmentBooking> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/appointments"
            val payload = JSONObject().apply {
                put("name", name.trim())
                put("email", email.trim().lowercase())
                if (phone.isNotBlank()) put("phone", phone.trim())
                put("service", service.ifBlank { "AI Strategy & Consultation" })
                put("appointment_date", appointmentDate.trim())
                put("appointment_time", appointmentTime.trim())
                if (notes.isNotBlank()) put("notes", notes.trim())
                put("status", "pending")
                if (!userId.isNullOrBlank()) put("user_id", userId)
            }

            val body = payload.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .addHeader("Prefer", "return=representation")
                .post(body)
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Supabase insert error: code=${response.code}, body=$responseBody")
                throw IllegalStateException("Supabase rejected booking (HTTP ${response.code}): $responseBody")
            }

            val insertedJson = runCatching {
                if (responseBody.trim().startsWith("[")) {
                    JSONArray(responseBody).optJSONObject(0)
                } else {
                    JSONObject(responseBody)
                }
            }.getOrNull()

            val id = insertedJson?.optString("id", "") ?: ""
            val createdAt = insertedJson?.optString("created_at", "") ?: ""

            AppointmentBooking(
                id = id,
                name = name,
                email = email,
                phone = phone,
                service = service,
                appointmentDate = appointmentDate,
                appointmentTime = appointmentTime,
                notes = notes,
                status = "pending",
                createdAt = createdAt,
                userId = userId
            )
        }
    }

    suspend fun fetchAppointments(limit: Int = 10): Result<List<AppointmentBooking>> = withContext(Dispatchers.IO) {
        runCatching {
            val endpoint = "$supabaseUrl/rest/v1/appointments?order=created_at.desc&limit=$limit"
            val request = Request.Builder()
                .url(endpoint)
                .addHeader("apikey", apiKey)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Accept", "application/json")
                .get()
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                throw IllegalStateException("Supabase query error (HTTP ${response.code}): $responseBody")
            }

            val jsonArray = JSONArray(responseBody)
            val list = mutableListOf<AppointmentBooking>()
            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.optJSONObject(i) ?: continue
                list.add(
                    AppointmentBooking(
                        id = item.optString("id", ""),
                        name = item.optString("name", ""),
                        email = item.optString("email", ""),
                        phone = item.optString("phone", ""),
                        service = item.optString("service", "AI Strategy & Consultation"),
                        appointmentDate = item.optString("appointment_date", ""),
                        appointmentTime = item.optString("appointment_time", ""),
                        notes = item.optString("notes", ""),
                        status = item.optString("status", "pending"),
                        createdAt = item.optString("created_at", ""),
                        userId = if (!item.isNull("user_id")) item.optString("user_id") else null
                    )
                )
            }
            list
        }
    }
}
