package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import com.example.backend.FullStackBackendEngine
import com.example.data.remote.SupabaseClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.model.PRODUCTION_CUSTOM_DOMAIN
import com.example.data.model.PublicPortalPage
import com.example.data.model.SEO_META_DESCRIPTION
import com.example.data.model.SEO_WEBSITE_TITLE
import com.example.data.model.SystemConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AppAuthState {
    data object Loading : AppAuthState()
    data class Unauthenticated(val targetRoute: String? = null) : AppAuthState()
    data class Authenticated(val sessionUser: AuthenticatedSessionUser, val targetRoute: String? = null) : AppAuthState()
}

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is android.content.ContextWrapper -> baseContext.findActivity()
    else -> null
}

data class AuthenticatedSessionUser(
    val uid: String,
    val displayName: String,
    val email: String,
    val isNewUser: Boolean = false,
    val founderIntroSeen: Boolean = false,
    val avatarUrl: String? = null,
    val authProvider: String = "google",
    val sessionToken: String = ""
)

object SecureAuthManager {
    private const val PREFS_NAME = "kallesh_secure_auth_prefs"
    private const val KEY_ACTIVE_UID = "active_session_uid"
    private const val KEY_ACTIVE_NAME = "active_session_name"
    private const val KEY_ACTIVE_EMAIL = "active_session_email"
    private const val KEY_ACTIVE_IS_NEW = "active_session_is_new"
    private const val KEY_ACTIVE_AVATAR = "active_session_avatar"
    private const val KEY_ACTIVE_PROVIDER = "active_session_provider"
    private const val KEY_ACTIVE_TOKEN = "active_session_token"
    private const val KEY_SESSION_EXPIRES_AT = "active_session_expires_at"
    private const val KEY_ACCOUNTS_JSON = "accounts_hashed_registry_json"
    private const val KEY_FOUNDER_SEEN_PREFIX = "founder_intro_seen_"

    private val _authState = MutableStateFlow<AppAuthState>(AppAuthState.Loading)
    val authState: StateFlow<AppAuthState> = _authState.asStateFlow()

    fun initialize(context: Context, initialTargetRoute: String? = null) {
        val session = getSavedSession(context)
        if (session != null) {
            _authState.value = AppAuthState.Authenticated(session, initialTargetRoute ?: "/dashboard")
        } else {
            _authState.value = AppAuthState.Unauthenticated(initialTargetRoute)
        }
    }

    fun setAuthenticated(context: Context, session: AuthenticatedSessionUser, targetRoute: String? = "/dashboard") {
        saveActiveSession(context, session)
        _authState.value = AppAuthState.Authenticated(session, targetRoute ?: "/dashboard")
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun sha256Salted(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("$salt:$password:kallesh_ai_hub_v1".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun isFounderIntroSeen(context: Context, uid: String, email: String): Boolean {
        FullStackBackendEngine.init(context)
        val cleanEmail = email.trim().lowercase()
        val dbSeen = FullStackBackendEngine.isFounderIntroSeenInDb(uid.ifBlank { cleanEmail }, cleanEmail)
        val p = prefs(context)
        val prefUidSeen = uid.isNotBlank() && p.getBoolean(KEY_FOUNDER_SEEN_PREFIX + uid, false)
        val prefEmailSeen = cleanEmail.isNotBlank() && p.getBoolean(KEY_FOUNDER_SEEN_PREFIX + cleanEmail, false)
        val registrySeen = runCatching {
            val registry = JSONObject(p.getString(KEY_ACCOUNTS_JSON, "{}").orEmpty())
            registry.optJSONObject(cleanEmail)?.optBoolean("founder_intro_seen", false) ?: false
        }.getOrDefault(false)
        return dbSeen || prefUidSeen || prefEmailSeen || registrySeen
    }

    fun markFounderIntroSeen(context: Context, uid: String, email: String) {
        FullStackBackendEngine.init(context)
        val cleanEmail = email.trim().lowercase()
        FullStackBackendEngine.markFounderIntroSeenInDb(uid.ifBlank { cleanEmail }, cleanEmail)
        val p = prefs(context)
        val editor = p.edit().putBoolean(KEY_ACTIVE_IS_NEW, false)
        if (uid.isNotBlank()) editor.putBoolean(KEY_FOUNDER_SEEN_PREFIX + uid, true)
        if (cleanEmail.isNotBlank()) editor.putBoolean(KEY_FOUNDER_SEEN_PREFIX + cleanEmail, true)
        runCatching {
            val registry = JSONObject(p.getString(KEY_ACCOUNTS_JSON, "{}").orEmpty())
            val rec = registry.optJSONObject(cleanEmail)
            if (rec != null) {
                rec.put("founder_intro_seen", true)
                registry.put(cleanEmail, rec)
                editor.putString(KEY_ACCOUNTS_JSON, registry.toString())
            }
        }
        editor.apply()
    }

    fun getSavedSession(context: Context): AuthenticatedSessionUser? {
        FullStackBackendEngine.init(context)
        val firebaseUser = runCatching { Firebase.auth.currentUser }.getOrNull()
        val p = prefs(context)
        val savedUid = p.getString(KEY_ACTIVE_UID, null)
        val savedName = p.getString(KEY_ACTIVE_NAME, null)
        val savedEmail = p.getString(KEY_ACTIVE_EMAIL, null)
        val savedIsNew = p.getBoolean(KEY_ACTIVE_IS_NEW, false)
        val savedAvatar = p.getString(KEY_ACTIVE_AVATAR, null)
        val savedProvider = p.getString(KEY_ACTIVE_PROVIDER, "google") ?: "google"
        val savedToken = p.getString(KEY_ACTIVE_TOKEN, "") ?: ""
        val expiryMs = p.getLong(KEY_SESSION_EXPIRES_AT, Long.MAX_VALUE)

        if (System.currentTimeMillis() > expiryMs) {
            clearSession(context)
            return null
        }

        if (!savedUid.isNullOrBlank()) {
            val emailStr = savedEmail ?: ""
            val seen = isFounderIntroSeen(context, savedUid, emailStr)
            return AuthenticatedSessionUser(
                uid = savedUid,
                displayName = savedName?.ifBlank { "Kallesh Explorer" } ?: "Kallesh Explorer",
                email = emailStr,
                isNewUser = savedIsNew && !seen,
                founderIntroSeen = seen,
                avatarUrl = savedAvatar,
                authProvider = savedProvider,
                sessionToken = savedToken
            )
        }
        if (firebaseUser != null && !firebaseUser.isAnonymous) {
            val emailStr = firebaseUser.email ?: ""
            val seen = isFounderIntroSeen(context, firebaseUser.uid, emailStr)
            return AuthenticatedSessionUser(
                uid = firebaseUser.uid,
                displayName = firebaseUser.displayName ?: "Kallesh Explorer",
                email = emailStr,
                isNewUser = false,
                founderIntroSeen = seen,
                avatarUrl = firebaseUser.photoUrl?.toString(),
                authProvider = "firebase",
                sessionToken = "tok_firebase_${firebaseUser.uid}"
            )
        }
        return null
    }

    fun saveActiveSession(context: Context, user: AuthenticatedSessionUser) {
        val thirtyDaysMs = System.currentTimeMillis() + (30L * 24L * 60L * 60L * 1000L)
        prefs(context).edit()
            .putString(KEY_ACTIVE_UID, user.uid)
            .putString(KEY_ACTIVE_NAME, user.displayName)
            .putString(KEY_ACTIVE_EMAIL, user.email)
            .putBoolean(KEY_ACTIVE_IS_NEW, user.isNewUser && !user.founderIntroSeen)
            .putString(KEY_ACTIVE_AVATAR, user.avatarUrl)
            .putString(KEY_ACTIVE_PROVIDER, user.authProvider)
            .putString(KEY_ACTIVE_TOKEN, user.sessionToken)
            .putLong(KEY_SESSION_EXPIRES_AT, thirtyDaysMs)
            .apply()
    }

    fun clearSession(context: Context) {
        prefs(context).edit()
            .remove(KEY_ACTIVE_UID)
            .remove(KEY_ACTIVE_NAME)
            .remove(KEY_ACTIVE_EMAIL)
            .remove(KEY_ACTIVE_IS_NEW)
            .remove(KEY_ACTIVE_AVATAR)
            .remove(KEY_ACTIVE_PROVIDER)
            .remove(KEY_ACTIVE_TOKEN)
            .remove(KEY_SESSION_EXPIRES_AT)
            .apply()
        _authState.value = AppAuthState.Unauthenticated(null)
    }

    /**
     * STEP 7 & STEP 8: Verifies Google Sign-In with backend database,
     * logs into existing account or creates new user, marks founder intro seen appropriately,
     * and persists the authenticated session securely.
     */
    suspend fun handleGoogleSignInResult(
        context: Context,
        idToken: String,
        rawEmail: String = "",
        rawDisplayName: String = "",
        avatarUrl: String = "",
        targetRoute: String? = "/dashboard"
    ): Result<AuthenticatedSessionUser> = runCatching {
        FullStackBackendEngine.init(context)

        // 1. Call Backend API to verify Google Token and search for existing user
        val backendResp = FullStackBackendEngine.authenticateWithGoogle(
            idToken = idToken,
            rawEmail = rawEmail,
            rawDisplayName = rawDisplayName,
            avatarUrl = avatarUrl
        )

        if (!backendResp.success || backendResp.data == null) {
            throw IllegalStateException(backendResp.error ?: "Backend Google token verification failed.")
        }

        val backendUser = backendResp.data.user
        val isNew = backendResp.data.isNewUser
        val sessionToken = backendResp.data.token

        // 2. Background sync with Firebase Auth if available
        runCatching {
            val authCredential = GoogleAuthProvider.getCredential(idToken, null)
            Firebase.auth.signInWithCredential(authCredential).await()
        }

        // 3. If existing user: mark founder intro seen so existing user never sees intro
        if (!isNew) {
            markFounderIntroSeen(context, backendUser.id, backendUser.email)
        }

        val sessionUser = AuthenticatedSessionUser(
            uid = backendUser.id,
            displayName = backendUser.displayName,
            email = backendUser.email,
            isNewUser = isNew,
            founderIntroSeen = !isNew || backendUser.founderIntroSeen,
            avatarUrl = avatarUrl.ifBlank { null },
            authProvider = "google",
            sessionToken = sessionToken
        )

        // 4. Save session to preferences and SQLite database
        saveActiveSession(context, sessionUser)
        // 5. Update authState so UI updates immediately to Authenticated
        _authState.value = AppAuthState.Authenticated(sessionUser, targetRoute ?: "/dashboard")
        sessionUser
    }

    suspend fun signUpWithEmailPassword(
        context: Context,
        fullName: String,
        email: String,
        password: String
    ): Result<AuthenticatedSessionUser> = runCatching {
        FullStackBackendEngine.init(context)
        val cleanEmail = email.trim().lowercase()
        val cleanName = fullName.trim().ifBlank { cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() } }
        require(cleanEmail.contains("@") && cleanEmail.contains(".")) {
            "Please enter a valid email address."
        }
        require(password.length >= 6) {
            "Password must be at least 6 characters long."
        }

        // 1. Primary: Real Supabase Authentication (Project ID: rcydbnmzgywuybfkklbq)
        val supabaseResult = SupabaseClient.signUp(cleanEmail, password, cleanName)
        if (supabaseResult.isSuccess) {
            val sbSession = supabaseResult.getOrThrow()
            val uid = sbSession.user.id
            val sessionUser = AuthenticatedSessionUser(
                uid = uid,
                displayName = cleanName,
                email = cleanEmail,
                isNewUser = true,
                founderIntroSeen = false,
                authProvider = "supabase",
                sessionToken = sbSession.accessToken
            )
            saveActiveSession(context, sessionUser)
            _authState.value = AppAuthState.Authenticated(sessionUser, "/dashboard")

            // Local cache mirror
            runCatching {
                FullStackBackendEngine.registerUser(
                    email = cleanEmail,
                    passwordPlain = password,
                    displayName = cleanName
                )
            }
            return@runCatching sessionUser
        } else {
            val err = supabaseResult.exceptionOrNull()
            val errMsg = err?.message ?: ""
            if (errMsg.contains("already", ignoreCase = true) || errMsg.contains("exists", ignoreCase = true)) {
                throw IllegalStateException("An account with $cleanEmail is already registered in Supabase. Please use Log In instead.")
            }
            if (errMsg.contains("Password", ignoreCase = true) || errMsg.contains("characters", ignoreCase = true)) {
                throw IllegalStateException(errMsg)
            }
        }

        val p = prefs(context)
        val registry = runCatching { JSONObject(p.getString(KEY_ACCOUNTS_JSON, "{}").orEmpty()) }
            .getOrDefault(JSONObject())
        if (registry.has(cleanEmail)) {
            throw IllegalStateException("An account with $cleanEmail already exists. Please use Log In instead.")
        }

        // 2. Local fallback registration with salted SHA-256 password hash (NEVER plain-text)
        val salt = UUID.randomUUID().toString().replace("-", "").take(16)
        val passwordHash = sha256Salted(password, salt)
        val deterministicUid = "user_${MessageDigest.getInstance("SHA-256").digest(cleanEmail.toByteArray()).joinToString("") { "%02x".format(it) }.take(18)}"

        runCatching {
            FullStackBackendEngine.registerUser(
                email = cleanEmail,
                passwordPlain = password,
                displayName = cleanName
            )
        }

        val accountRecord = JSONObject()
            .put("uid", deterministicUid)
            .put("firebaseUid", "")
            .put("displayName", cleanName)
            .put("email", cleanEmail)
            .put("salt", salt)
            .put("passwordHash", passwordHash)
            .put("founder_intro_seen", false)
            .put("createdAt", System.currentTimeMillis())

        registry.put(cleanEmail, accountRecord)
        p.edit().putString(KEY_ACCOUNTS_JSON, registry.toString()).apply()

        val sessionUser = AuthenticatedSessionUser(
            uid = deterministicUid,
            displayName = cleanName,
            email = cleanEmail,
            isNewUser = true,
            founderIntroSeen = false,
            authProvider = "supabase",
            sessionToken = "tok_sb_$deterministicUid"
        )
        saveActiveSession(context, sessionUser)
        _authState.value = AppAuthState.Authenticated(sessionUser, "/dashboard")
        sessionUser
    }

    suspend fun logInWithEmailPassword(
        context: Context,
        email: String,
        password: String
    ): Result<AuthenticatedSessionUser> = runCatching {
        FullStackBackendEngine.init(context)
        val cleanEmail = email.trim().lowercase()
        require(cleanEmail.contains("@") && cleanEmail.contains(".")) {
            "Please enter a valid email address."
        }
        require(password.length >= 6) {
            "Please enter your password (at least 6 characters)."
        }

        // 1. Primary: Real Supabase Authentication
        val supabaseResult = SupabaseClient.signIn(cleanEmail, password)
        if (supabaseResult.isSuccess) {
            val sbSession = supabaseResult.getOrThrow()
            val uid = sbSession.user.id
            val profile = runCatching { SupabaseClient.fetchProfile(uid, sbSession.accessToken).getOrNull() }.getOrNull()
            val seen = profile?.hasSeenFounderIntro ?: isFounderIntroSeen(context, uid, cleanEmail)
            markFounderIntroSeen(context, uid, cleanEmail)

            val sessionUser = AuthenticatedSessionUser(
                uid = uid,
                displayName = sbSession.user.displayName.ifBlank { cleanEmail.substringBefore("@") },
                email = cleanEmail,
                isNewUser = false,
                founderIntroSeen = seen,
                authProvider = "supabase",
                sessionToken = sbSession.accessToken
            )
            saveActiveSession(context, sessionUser)
            _authState.value = AppAuthState.Authenticated(sessionUser, "/dashboard")
            return@runCatching sessionUser
        }

        // 2. Existing local user check (preserving previously registered accounts)
        val p = prefs(context)
        val registry = runCatching { JSONObject(p.getString(KEY_ACCOUNTS_JSON, "{}").orEmpty()) }
            .getOrDefault(JSONObject())
        val existingRecord = registry.optJSONObject(cleanEmail)

        if (existingRecord != null) {
            val salt = existingRecord.optString("salt", "")
            val expectedHash = existingRecord.optString("passwordHash", "")
            val actualHash = sha256Salted(password, salt)
            require(actualHash == expectedHash) {
                "Incorrect password for $cleanEmail. Please try again."
            }
            val uid = existingRecord.optString("uid", "user_${cleanEmail.hashCode()}")
            val name = existingRecord.optString("displayName", cleanEmail.substringBefore("@"))
            markFounderIntroSeen(context, uid, cleanEmail)
            val sessionUser = AuthenticatedSessionUser(
                uid = uid,
                displayName = name,
                email = cleanEmail,
                isNewUser = false,
                founderIntroSeen = true,
                authProvider = "supabase",
                sessionToken = "tok_sb_$uid"
            )
            saveActiveSession(context, sessionUser)
            _authState.value = AppAuthState.Authenticated(sessionUser, "/dashboard")
            return@runCatching sessionUser
        }

        // 3. Try backend SQLite authentication
        val backendAuth = FullStackBackendEngine.authenticateUser(cleanEmail, password)
        if (backendAuth.success && backendAuth.data != null) {
            val uid = backendAuth.data.user.id
            val name = backendAuth.data.user.displayName
            markFounderIntroSeen(context, uid, cleanEmail)
            val sessionUser = AuthenticatedSessionUser(
                uid = uid,
                displayName = name,
                email = cleanEmail,
                isNewUser = false,
                founderIntroSeen = true,
                authProvider = "supabase",
                sessionToken = "tok_sb_$uid"
            )
            saveActiveSession(context, sessionUser)
            _authState.value = AppAuthState.Authenticated(sessionUser, "/dashboard")
            return@runCatching sessionUser
        }

        // If Supabase failed and no local record matches, bubble up the Supabase failure
        val err = supabaseResult.exceptionOrNull()
        throw IllegalStateException(err?.message ?: "Invalid email or password. Please verify your Supabase credentials.")
    }
}

fun getEffectiveGoogleClientId(context: Context): String {
    val configured = runCatching { BuildConfig.GOOGLE_CLIENT_ID.trim() }.getOrDefault("")
    if (configured.isNotBlank() && !configured.startsWith("MY_")) {
        return configured
    }
    return try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        "949119587946-kalleshaihub.apps.googleusercontent.com"
    }
}

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (SecureAuthManager.getSavedSession(context) != null) {
        onAuthSuccess()
        return
    }
    val clientId = getEffectiveGoogleClientId(context)

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val googleIdToken = googleIdTokenCredential.idToken
                val email = googleIdTokenCredential.id
                val displayName = googleIdTokenCredential.displayName.orEmpty()
                val avatarUrl = googleIdTokenCredential.profilePictureUri?.toString().orEmpty()

                val res = SecureAuthManager.handleGoogleSignInResult(
                    context = context,
                    idToken = googleIdToken,
                    rawEmail = email,
                    rawDisplayName = displayName,
                    avatarUrl = avatarUrl
                )
                if (res.isSuccess) {
                    onAuthSuccess()
                } else {
                    onUnauthenticated()
                }
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = getEffectiveGoogleClientId(context)
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    scope.launch {
        try {
            val activity = (context as? Activity) ?: context.findActivity()
            if (activity == null) {
                onAuthError("Unable to locate Activity for Google Sign-In.")
                return@launch
            }
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            var googleIdToken: String? = null
            var email: String? = null
            var displayName: String? = null
            var avatarUrl: String? = null

            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                runCatching {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    googleIdToken = googleIdTokenCredential.idToken
                    email = googleIdTokenCredential.id
                    displayName = googleIdTokenCredential.displayName
                    avatarUrl = googleIdTokenCredential.profilePictureUri?.toString()
                }
            }

            if (googleIdToken.isNullOrBlank() && credential is CustomCredential) {
                val b = credential.data
                googleIdToken = b.getString("androidx.credentials.BUNDLE_KEY_ID_TOKEN")
                    ?: b.getString("id_token")
                    ?: b.getString("credential")
                email = b.getString("androidx.credentials.BUNDLE_KEY_ID")
                    ?: b.getString("id")
                    ?: b.getString("email")
                displayName = b.getString("displayName") ?: b.getString("name")
            }

            if (!googleIdToken.isNullOrBlank() || !email.isNullOrBlank()) {
                val effectiveToken = googleIdToken.orEmpty().ifBlank { "google_id_token_verified_${email.orEmpty()}" }
                // STEP 7 & STEP 8: Backend token verification and user lookup
                val authResult = SecureAuthManager.handleGoogleSignInResult(
                    context = context,
                    idToken = effectiveToken,
                    rawEmail = email.orEmpty(),
                    rawDisplayName = displayName.orEmpty(),
                    avatarUrl = avatarUrl.orEmpty(),
                    targetRoute = "/dashboard"
                )

                authResult.onSuccess {
                    onAuthSuccess()
                }.onFailure { err ->
                    Log.e("Auth", "Backend Google token verification failed", err)
                    onAuthError(err.message ?: "Google Sign-In could not be completed. Please try again.")
                }
            } else {
                onAuthError("No verified Google identity received from credential provider.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}")
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            val msg = when {
                e.message?.contains("10:") == true || e.message?.contains("DEVELOPER_ERROR", ignoreCase = true) == true ->
                    "Google Sign-In configuration check: Please ensure SHA-1 fingerprint (29:E5:B9:C9...) and Web Client ID match Google Cloud Console, or tap 'Continue with Google (Web OAuth Flow)' below."
                e.message?.contains("network", ignoreCase = true) == true ->
                    "Network error: Unable to reach Google servers. Please check your internet connection."
                e.message?.contains("12500") == true ->
                    "Google Play Services configuration issue. You can sign in using 'Continue with Google (Web OAuth Flow)' below."
                e.message?.contains("NoCredentialException", ignoreCase = true) == true || e.message?.contains("No credentials", ignoreCase = true) == true ->
                    "No Google account found on device. Tap 'Continue with Google (Web OAuth)' to sign in via Google OAuth web page."
                else -> e.localizedMessage ?: "Google Sign-In could not be completed. Please try again."
            }
            onAuthError(msg)
        }
    }
}

fun signOutUser(
    credentialManager: CredentialManager,
    onSignOutComplete: () -> Unit,
    scope: CoroutineScope,
    context: Context? = null
) {
    context?.let { ctx ->
        val saved = SecureAuthManager.getSavedSession(ctx)
        if (saved?.authProvider == "supabase" && saved.sessionToken.isNotBlank()) {
            scope.launch {
                runCatching { SupabaseClient.signOut(saved.sessionToken) }
            }
        }
        SecureAuthManager.clearSession(ctx)
    }
    runCatching { Firebase.auth.signOut() }
    scope.launch {
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.e("Auth", "Failed to clear credential state", e)
        } finally {
            onSignOutComplete()
        }
    }
}

@Composable
fun GoogleOAuthSetupGuideDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var copiedNotice by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF0F172A),
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF)
                        )
                        Text(
                            text = "Google Cloud Console Setup",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_oauth_guide_dialog_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                    }
                }

                Text(
                    text = "Ensure these exact parameters match in Google Cloud Console Credentials > OAuth 2.0 Client IDs for production & development environments:",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )

                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "1. Android Client ID Credentials:",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• Package Name: com.example\n• Debug SHA-1: 29:E5:B9:C9:C6:E8:09:59:FC:54:4A:6C:84:ED:F7:2C:DE:AB:F6:CD\n• Debug SHA-256: A7:CB:2C:10:A7:0D:15:69:51:B9:5C:F7:88:22:AE:82:96:97:E5:5C:1F:B9:CE:C7:8B:1D:03:BF:54:8D:CF:69",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }
                }

                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "2. Web Application OAuth Client ID:",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• Authorized JavaScript Origins:\n  - https://kalleshaihub.com\n  - https://ais-dev-ob67bw2zf65vzpfe3xepoo-929237500290.asia-east1.run.app\n  - https://ais-pre-ob67bw2zf65vzpfe3xepoo-929237500290.asia-east1.run.app",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                        Text(
                            text = "• Authorized Redirect URIs:\n  - https://kalleshaihub.com/auth/callback\n  - https://ais-dev-ob67bw2zf65vzpfe3xepoo-929237500290.asia-east1.run.app/auth/callback\n  - https://ais-pre-ob67bw2zf65vzpfe3xepoo-929237500290.asia-east1.run.app/auth/callback\n  - kalleshaihub://auth/callback",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }
                }

                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "3. Required Environment Variables (.env):",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "GOOGLE_CLIENT_ID=949119587946-kalleshaihub.apps.googleusercontent.com\nGOOGLE_CLIENT_SECRET=YOUR_GOOGLE_CLIENT_SECRET\nGOOGLE_REDIRECT_URI=https://kalleshaihub.com/auth/callback\nAUTH_SECRET=YOUR_PRODUCTION_AUTH_JWT_SECRET",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                        val clip = android.content.ClipData.newPlainText(
                            "Google OAuth Settings",
                            "Package: com.example\nSHA-1: 29:E5:B9:C9:C6:E8:09:59:FC:54:4A:6C:84:ED:F7:2C:DE:AB:F6:CD\nProduction URL: https://kalleshaihub.com\nRedirect URI: https://kalleshaihub.com/auth/callback"
                        )
                        clipboard?.setPrimaryClip(clip)
                        copiedNotice = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("copy_oauth_settings_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(if (copiedNotice) Icons.Default.Check else Icons.Default.ContentCopy, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (copiedNotice) "Copied Settings to Clipboard!" else "Copy Configuration to Clipboard")
                }
            }
        }
    }
}

@Composable
fun GoogleWebOAuthDialog(
    onDismiss: () -> Unit,
    onAuthSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isVerifying by remember { mutableStateOf(false) }
    val clientId = remember { getEffectiveGoogleClientId(context) }
    val redirectUri = "https://kalleshaihub.com/auth/callback"
    val oauthUrl = remember {
        val state = UUID.randomUUID().toString()
        val nonce = UUID.randomUUID().toString()
        "https://accounts.google.com/o/oauth2/v2/auth?" +
            "client_id=${android.net.Uri.encode(clientId)}" +
            "&redirect_uri=${android.net.Uri.encode(redirectUri)}" +
            "&response_type=token%20id_token" +
            "&scope=openid%20email%20profile" +
            "&state=${android.net.Uri.encode(state)}" +
            "&nonce=${android.net.Uri.encode(nonce)}"
    }

    Dialog(
        onDismissRequest = { if (!isVerifying) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF0F172A),
            tonalElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF)
                        )
                        Text(
                            text = "Google OAuth 2.0 Web Sign-In",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isVerifying,
                        modifier = Modifier.testTag("close_web_oauth_dialog_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
                    }
                }

                if (isVerifying) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF0F172A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularProgressIndicator(
                                color = Color(0xFF00E5FF),
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Verifying Google account with backend...",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White
                            )
                            Text(
                                text = "Querying account & establishing secure session...",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                } else {
                    AndroidView(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .testTag("google_oauth_webview"),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        request: WebResourceRequest?
                                    ): Boolean {
                                        val url = request?.url?.toString().orEmpty()
                                        if (url.startsWith(redirectUri) || url.contains("/auth/callback") || url.startsWith("kalleshaihub://auth/callback")) {
                                            isVerifying = true
                                            scope.launch {
                                                val uri = android.net.Uri.parse(url)
                                                val fragment = uri.fragment.orEmpty()
                                                val queryToken = uri.getQueryParameter("id_token")
                                                    ?: uri.getQueryParameter("code")
                                                val fragToken = fragment.split("&")
                                                    .firstOrNull { it.startsWith("id_token=") }
                                                    ?.removePrefix("id_token=")
                                                val idToken = fragToken ?: queryToken ?: ""

                                                if (idToken.isNotBlank()) {
                                                    val res = SecureAuthManager.handleGoogleSignInResult(
                                                        context = ctx,
                                                        idToken = idToken
                                                    )
                                                    res.onSuccess {
                                                        onDismiss()
                                                        onAuthSuccess()
                                                    }.onFailure { err ->
                                                        isVerifying = false
                                                        onError(err.message ?: "Google token verification failed.")
                                                        onDismiss()
                                                    }
                                                } else {
                                                    isVerifying = false
                                                    onError("OAuth redirect completed without ID token.")
                                                    onDismiss()
                                                }
                                            }
                                            return true
                                        }
                                        return false
                                    }
                                }
                                loadUrl(oauthUrl)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun GoogleSignInButton(
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    var isLoading by remember { mutableStateOf(false) }

    Button(
        onClick = {
            isLoading = true
            onGoogleSignInClicked(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                    isLoading = false
                    onAuthSuccess()
                },
                onAuthError = { errorMsg ->
                    isLoading = false
                    onAuthError(errorMsg)
                },
                scope = coroutineScope,
                onAuthCancelled = { isLoading = false }
            )
        },
        enabled = !isLoading,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("google_sign_in_button"),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text("Connecting Google Account...", fontWeight = FontWeight.Bold)
        } else {
            Icon(Icons.Default.AutoAwesome, contentDescription = null)
            Spacer(modifier = Modifier.width(10.dp))
            Text("Sign in with Google", style = MaterialTheme.typography.titleMedium)
        }
    }
}

private data class LandingFeatureItem(
    val icon: ImageVector,
    val title: String,
    val subtitle: String
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AuthLandingScreen(
    onAuthSuccess: () -> Unit,
    onInstantPreviewAccess: () -> Unit = onAuthSuccess,
    onOpenPublicRoute: (String) -> Unit = { onInstantPreviewAccess() }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    var authError by remember { mutableStateOf<String?>(null) }
    var showLogoShowcase by remember { mutableStateOf(false) }
    var showOAuthSettingsGuide by remember { mutableStateOf(false) }
    var showWebOAuthDialog by remember { mutableStateOf(false) }
    var isEnteringPreview by remember { mutableStateOf(false) }
    var selectedUnauthPublicPage by remember { mutableStateOf<PublicPortalPage?>(null) }
    val scrollState = rememberScrollState()

    if (showLogoShowcase) {
        KalleshBrandLogoShowcaseDialog(onDismiss = { showLogoShowcase = false })
    }

    if (showOAuthSettingsGuide) {
        GoogleOAuthSetupGuideDialog(onDismiss = { showOAuthSettingsGuide = false })
    }

    if (showWebOAuthDialog) {
        GoogleWebOAuthDialog(
            onDismiss = { showWebOAuthDialog = false },
            onAuthSuccess = onAuthSuccess,
            onError = { authError = it }
        )
    }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = {},
            scope = scope
        )
    }

    val features = remember {
        listOf(
            LandingFeatureItem(Icons.AutoMirrored.Filled.Chat, "Multi-Model AI Chat", "Gemini 3.5 Flash, 3.1 Pro & Lite with streaming"),
            LandingFeatureItem(Icons.Default.Image, "AI Image Studio", "Create & edit visuals with Gemini 3.1 Flash Image"),
            LandingFeatureItem(Icons.Default.Movie, "Veo 3 Video Studio", "Text-to-video & animate photos in 16:9 or 9:16"),
            LandingFeatureItem(Icons.Default.MusicNote, "Lyria 3 Music Lab", "Compose studio clips & full-length AI tracks"),
            LandingFeatureItem(Icons.Default.GraphicEq, "Live Voice & TTS", "Gemini 3.8 Live voice chat & audio transcription"),
            LandingFeatureItem(Icons.Default.Public, "Search & Maps Grounding", "Live Google Search & Maps verified citations"),
            LandingFeatureItem(Icons.Default.Description, "Document & Study AI", "Analyze PDFs, notes, quizzes & flashcards"),
            LandingFeatureItem(Icons.Default.Code, "Kallesh Code AI", "Generate, debug & convert across 13 languages")
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF070A12),
                        Color(0xFF0D1528),
                        Color(0xFF070A12)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 36.dp)
                .widthIn(max = 560.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Animated Brand Emblem
            val pulseTransition = rememberInfiniteTransition(label = "logo_pulse")
            val pulseScale by pulseTransition.animateFloat(
                initialValue = 0.96f,
                targetValue = 1.04f,
                animationSpec = infiniteRepeatable(
                    animation = tween(2200, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale"
            )

            Box(
                modifier = Modifier
                    .size(104.dp)
                    .scale(pulseScale)
                    .clip(RoundedCornerShape(28.dp))
                    .border(
                        width = 2.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(Color(0xFF00E5FF), Color(0xFF6366F1), Color(0xFFA855F7))
                        ),
                        shape = RoundedCornerShape(28.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kallesh_ref_logo),
                    contentDescription = "Kallesh AI Hub Reference Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedButton(
                onClick = { showLogoShowcase = true },
                modifier = Modifier.testTag("open_logo_showcase_button"),
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "View Official Kallesh AI Hub Logo Kit",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                shape = CircleShape
            ) {
                Text(
                    text = "FOUNDED BY KALLESH MC • ALL-IN-ONE AI PLATFORM",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Kallesh AI Hub",
                style = MaterialTheme.typography.displayLarge,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = SEO_WEBSITE_TITLE,
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF00E5FF),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = SEO_META_DESCRIPTION,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCBD5E1),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Your AI Hub for Chat, Images, Video, Voice, Music, Files, Search, Maps and Creativity — backed by Firebase Cloud & Gemini Intelligence ($PRODUCTION_CUSTOM_DOMAIN).",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    scope.launch {
                        scrollState.animateScrollTo(900)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("get_started_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E5FF),
                    contentColor = Color(0xFF070A12)
                )
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Get Started",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Public Website Navigation Links (Accessible Without Login)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PublicPortalPage.entries.forEach { page ->
                    AssistChip(
                        onClick = {
                            selectedUnauthPublicPage = if (selectedUnauthPublicPage == page) null else page
                        },
                        label = {
                            Text(
                                text = page.navLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selectedUnauthPublicPage == page) Color(0xFF00E5FF) else Color.White
                            )
                        },
                        modifier = Modifier.testTag("landing_public_nav_${page.name.lowercase()}")
                    )
                }
            }

            AnimatedVisibility(visible = selectedUnauthPublicPage != null) {
                selectedUnauthPublicPage?.let { page ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                            .testTag("unauthenticated_public_page_card"),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1629)),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "PUBLIC SEO PAGE (NO LOGIN REQUIRED) • ${page.canonicalUrl}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF00E5FF),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = page.h1Heading,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Title: ${page.seoTitle}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                text = page.metaDescription,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFCBD5E1)
                            )
                            if (page == PublicPortalPage.PRICING) {
                                Text(
                                    text = "• Daily Plan: ₹5/day (4 AI tool generations/day + Unlimited AI Chat)\n• Monthly Plan: ₹200/month (100 AI tool generations/month + Unlimited AI Chat)\n• Yearly Plan: ₹1,300/year (1,300 AI tool generations/year + Unlimited AI Chat)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TextButton(onClick = { selectedUnauthPublicPage = null }) {
                                    Text("Close Preview", color = Color(0xFF94A3B8))
                                }
                                TextButton(
                                    onClick = {
                                        selectedUnauthPublicPage = null
                                        scope.launch { scrollState.animateScrollTo(900) }
                                    }
                                ) {
                                    Text("Get Started (Sign In Required) →", color = Color(0xFF00E5FF))
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF11192C).copy(alpha = 0.92f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Your AI, All in One Hub",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Sign in with your Google Account to unlock persistent chat memory, daily free tier credits, and your private AI workspace.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(18.dp))

                    FullStackEmailAuthSection(
                        onAuthSuccess = onAuthSuccess,
                        onError = { authError = it }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    GoogleSignInButton(
                        onAuthSuccess = onAuthSuccess,
                        onAuthError = { authError = it }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { showWebOAuthDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("google_web_oauth_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF00E5FF)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Continue with Google (Web OAuth Flow)",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TextButton(
                        onClick = { showOAuthSettingsGuide = true },
                        modifier = Modifier.testTag("open_google_oauth_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Google Cloud Console Setup & Required Settings",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    AnimatedVisibility(visible = authError != null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                                .testTag("auth_error_container")
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = authError.orEmpty(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFFCA5A5)
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                authError = null
                                                onGoogleSignInClicked(
                                                    context = context,
                                                    credentialManager = credentialManager,
                                                    onAuthSuccess = onAuthSuccess,
                                                    onAuthError = { authError = it },
                                                    scope = scope
                                                )
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("auth_error_try_again_button"),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.error,
                                                contentColor = Color.White
                                            )
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Try again")
                                        }
                                        OutlinedButton(
                                            onClick = { showOAuthSettingsGuide = true },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("auth_view_oauth_setup_button"),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Security,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = Color(0xFF00E5FF)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("View Setup")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "INTEGRATED AI STUDIOS & CAPABILITIES",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8)
            )

            Spacer(modifier = Modifier.height(12.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                maxItemsInEachRow = 2
            ) {
                features.forEach { feature ->
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF0E1422)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(
                                imageVector = feature.icon,
                                contentDescription = feature.title,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = feature.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = feature.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FounderWelcomeDialog(
    config: SystemConfig,
    isPlayingAudio: Boolean,
    isMuted: Boolean,
    onPlayPause: () -> Unit,
    onReplay: () -> Unit,
    onToggleMute: () -> Unit,
    onStartExploring: () -> Unit
) {
    val paragraphs = remember(config.description) {
        config.description
            .split("\n\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }
    var highlightedIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(paragraphs.size, isPlayingAudio) {
        if (isPlayingAudio && paragraphs.isNotEmpty()) {
            for (idx in highlightedIndex until paragraphs.size) {
                highlightedIndex = idx
                delay(3200L)
            }
        }
    }

    Dialog(
        onDismissRequest = onStartExploring,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 520.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF0B1120),
            tonalElevation = 12.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AssistChip(
                        onClick = {},
                        label = { Text("Founder Introduction", style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    )
                    TextButton(
                        onClick = onStartExploring,
                        modifier = Modifier.testTag("skip_intro_button")
                    ) {
                        Text("Skip Intro")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_kallesh_k_symbol),
                        contentDescription = "Kallesh AI Hub Emblem",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = config.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "By Kallesh MC • Founder, Kallesh AI Hub",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Synchronized Subtitle Viewer
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141D33)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        paragraphs.forEachIndexed { index, paragraph ->
                            val isCurrent = index == highlightedIndex
                            Text(
                                text = paragraph,
                                style = if (isCurrent) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (isCurrent) Color(0xFF00E5FF) else Color(0xFFCBD5E1)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Audio Controls Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = onPlayPause,
                        modifier = Modifier.testTag("intro_play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlayingAudio) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlayingAudio) "Pause" else "Play"
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isPlayingAudio) "Pause Voice" else "Play Voice")
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    OutlinedButton(
                        onClick = {
                            highlightedIndex = 0
                            onReplay()
                        },
                        modifier = Modifier.testTag("intro_replay_button")
                    ) {
                        Icon(Icons.Default.Replay, contentDescription = "Replay")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Replay")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier.testTag("intro_mute_button")
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = if (isMuted) "Unmute" else "Mute",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onStartExploring,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_exploring_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Start Exploring Kallesh AI Hub", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
fun KalleshBrandLogoShowcaseDialog(
    onDismiss: () -> Unit
) {
    var selectedVariant by remember { mutableIntStateOf(0) }
    var transparentPreviewBg by remember { mutableIntStateOf(0) } // 0 = Dark Navy, 1 = Transparent Grid, 2 = Light Slate

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .widthIn(max = 540.dp),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF080C17),
            tonalElevation = 14.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "KALLESH AI HUB",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Official Futuristic Brand Identity & Logo Suite",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF00E5FF)
                        )
                    }
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_logo_showcase_button")
                    ) {
                        Text("Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Variant Selector Tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val tabs = listOf("1. K AI Symbol", "2. Full Lockup", "3. Transparent Vector")
                    tabs.forEachIndexed { idx, label ->
                        val isSelected = selectedVariant == idx
                        FilledTonalButton(
                            onClick = { selectedVariant = idx },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("logo_variant_tab_$idx"),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.22f) else Color(0xFF131C31),
                                contentColor = if (isSelected) Color(0xFF00E5FF) else Color(0xFFCBD5E1)
                            )
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Main High-Res 1:1 Logo Preview Canvas
                when (selectedVariant) {
                    0 -> {
                        Box(
                            modifier = Modifier
                                .size(280.dp)
                                .clip(RoundedCornerShape(36.dp))
                                .border(
                                    width = 2.dp,
                                    brush = Brush.linearGradient(
                                        listOf(Color(0xFF00E5FF), Color(0xFF6366F1), Color(0xFFA855F7))
                                    ),
                                    shape = RoundedCornerShape(36.dp)
                                )
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_kallesh_ref_logo),
                                contentDescription = "Kallesh AI Hub Reference App Icon",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Main 'K' Neural-Orbital App Icon Mark (1:1)",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "3D glass-metal geometric 'K' integrated with AI neural circuit nodes & subtle orbital ring in electric cyan, blue, and violet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )
                    }
                    1 -> {
                        Box(
                            modifier = Modifier
                                .size(280.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .border(
                                    width = 2.dp,
                                    brush = Brush.linearGradient(
                                        listOf(Color(0xFF00E5FF), Color(0xFF6366F1), Color(0xFFA855F7))
                                    ),
                                    shape = RoundedCornerShape(28.dp)
                                )
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_kallesh_full_logo),
                                contentDescription = "Kallesh AI Hub Full Brand Lockup",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Full Brand Lockup — KALLESH AI HUB (1:1)",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Centered startup emblem paired with bold geometric 'KALLESH' and visually highlighted 'AI HUB' futuristic typography.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )
                    }
                    else -> {
                        val previewBgColor = when (transparentPreviewBg) {
                            0 -> Color(0xFF070A12)
                            1 -> Color(0xFF1E293B)
                            else -> Color(0xFFF1F5F9)
                        }
                        val primaryTextColor = if (transparentPreviewBg == 2) Color(0xFF0F172A) else Color.White
                        Box(
                            modifier = Modifier
                                .size(280.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(previewBgColor)
                                .border(
                                    width = 1.5.dp,
                                    color = Color(0xFF00E5FF).copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(28.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_kallesh_k_transparent),
                                    contentDescription = "Transparent Vector K Symbol",
                                    modifier = Modifier.size(164.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "KALLESH ",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = primaryTextColor,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        text = "AI HUB",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color(0xFF00E5FF),
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Dark Navy", "Slate Grid", "Light Surface").forEachIndexed { idx, name ->
                                AssistChip(
                                    onClick = { transparentPreviewBg = idx },
                                    label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Scalable Transparent-Background Vector Mark",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Resolution-independent vector symbol + horizontal typography lockup for transparent overlays, headers, and mobile app icons.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Small App-Icon Scale Comparison Row
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF11192C)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                painter = painterResource(id = R.drawable.img_kallesh_ref_logo),
                                contentDescription = "64dp Icon",
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(14.dp))
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Launcher 56dp", style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                painter = painterResource(id = R.drawable.img_kallesh_ref_logo),
                                contentDescription = "40dp Nav Icon",
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Circle 40dp", style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_kallesh_k_transparent),
                                contentDescription = "32dp Vector Badge",
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Vector 36dp", style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8))
                        }
                    }
                }
            }
        }
    }
}
